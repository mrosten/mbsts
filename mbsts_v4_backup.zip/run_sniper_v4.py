from mbsts_v4.main import main

if __name__ == "__main__":
    main()
