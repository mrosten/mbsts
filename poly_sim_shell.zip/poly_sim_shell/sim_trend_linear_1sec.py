"""
Simulator: Linear Trend Strategy (1-Sec Data)

A variation of the Trend/Swing strategies that seeks "Linear" moves.
- Data: 1-second intervals.
- Logic:
  1. Monitor price every 30 seconds starting at T+5m.
  2. If the "Winning" side's price increases linearly for 2 minutes (T+5 to T+7),
     execute EARLY ENTRY at T+7.
  3. Otherwise, fallback to standard T+9 entry.
"""
import os
import glob
import pandas as pd
import numpy as np
import time
import math
from datetime import datetime, timedelta

# --- Configuration ---
DEFAULT_BUDGET = 50.0
DRIFT_THRESHOLD = 0.0004         # 0.04% (Standard Trend Trigger)
SPREAD = 0.02
# --- Configuration ---
DEFAULT_BUDGET = 50.0
DRIFT_THRESHOLD = 0.0004         # 0.04% (Standard Trend Trigger)
SPREAD = 0.02
ROLLING_WINDOW_SEC = 300         # Increased to 5m for stable vol

# --- Pricing Model ---
def polymarket_pricing_model(current_price, strike_price, time_remaining_seconds, volatility_per_second):
    if time_remaining_seconds <= 0:
        return (0.99, 0.01) if current_price > strike_price else (0.01, 0.99)

    div_pct = (current_price - strike_price) / strike_price
    volatility_remaining = volatility_per_second * np.sqrt(time_remaining_seconds)

    if volatility_remaining == 0:
        up_price = 0.99 if div_pct > 0 else 0.01
        return up_price, 1.0 - up_price

    z_score = div_pct / volatility_remaining
    prob_up = 0.5 * (1 + math.erf(z_score / math.sqrt(2)))
    
    # Spread adj
    up_price = max(0.001, min(0.999, prob_up * (1 - SPREAD)))
    down_price = max(0.001, min(0.999, (1 - prob_up) * (1 - SPREAD)))

    return up_price, down_price

# --- Simulation Logic ---
class LinearTrendSimulation:
    def __init__(self, csv_file, balance):
        self.df = pd.read_csv(csv_file)
        # Handle formats
        try:
            self.df['Open Time'] = pd.to_datetime(self.df['Open Time'])
        except:
             pass
             
        self.balance = float(balance)
        self.start_balance = float(balance)
        self.trades = []
        self.wins = 0
        self.losses = 0

        # Pre-calc Volatility
        self.df['Log_Ret'] = np.log(self.df['Close'] / self.df['Close'].shift(1))
        self.df['Roll_Std'] = self.df['Log_Ret'].rolling(window=ROLLING_WINDOW_SEC).std()

    def run(self):
        print(f"\nProcessing {len(self.df)} datapoints (1-sec resolution)...")
        
        self.df['Window_Start'] = self.df['Open Time'].dt.floor('15min')
        windows = self.df.groupby('Window_Start')
        
        for window_start, group in windows:
            if len(group) < 60: continue 
            
            # Reset Index for 0..900s access
            g = group.reset_index(drop=True)
            
            open_price = g.iloc[0]['Open']
            final_price = g.iloc[-1]['Close']
            
            # State
            window_trade = None
            
            # We track the "Winning Option Price" every 30s starting from min 5 (300s)
            checkpoints = {} # {second: price}
            
            print(f"--- Window {window_start.strftime('%H:%M')} | Open: {open_price:.2f} ---")
            
            for i, row in g.iterrows():
                elapsed_sec = i
                if elapsed_sec >= 900: break
                
                curr_price = row['Close']
                curr_vol = row['Roll_Std'] if row['Roll_Std'] > 0 else 0.0001
                curr_vol *= 1.55 # Calibrated Multiplier (Data Analysis: 1.53x)
                
                # Determine "Winning Side" and its Price
                # We calculate standard pricing model
                time_left = 900 - elapsed_sec
                up_p, down_p = polymarket_pricing_model(curr_price, open_price, time_left, curr_vol)
                
                # Identify Leader
                leader_side = "UP" if curr_price > open_price else "DOWN"
                leader_price = up_p if leader_side == "UP" else down_p
                
                # --- SAMPLING LOGIC (Every 30s from 5m to 7m) ---
                if 300 <= elapsed_sec <= 420:
                    if elapsed_sec % 30 == 0:
                        checkpoints[elapsed_sec] = leader_price

                # --- T+6 (360s) STANDARD EARLY ENTRY ---
                if elapsed_sec == 360 and not window_trade:
                    drift = abs(curr_price - open_price) / open_price
                    # PRICE CAP < 0.85
                    if drift > DRIFT_THRESHOLD and leader_price < 0.85:
                        cost = min(50.0, self.balance * 0.15) 
                        shares = cost / leader_price
                        self.balance -= cost
                        window_trade = {
                            "type": "STD-T6",
                            "side": leader_side,
                            "entry": leader_price,
                            "shares": shares,
                            "cost": cost
                        }
                        print(f"  [T+6 STANDARD] Early Entry.")
                        print(f"    -> BUY {leader_side} @ {leader_price:.3f} (Cost: ${cost:.2f})")

                # --- TRIGGER LOGIC AT T+7m (420s) ---
                if elapsed_sec == 420 and not window_trade:
                    required_times = [300, 330, 360, 390, 420]
                    if all(t in checkpoints for t in required_times):
                        # Verify Linearity (Strict Increase OR Leeway)
                        prices = [checkpoints[t] for t in required_times]
                        is_linear = True
                        for j in range(1, len(prices)):
                            curr_p = prices[j]
                            prev_p = prices[j-1]
                            
                            if curr_p > prev_p:
                                continue # Strict increase is good
                            
                            # It is a Dip or Flat
                            dip = prev_p - curr_p
                            if dip > 0.05:
                                is_linear = False; break # Dip too large (> 5 cents)
                            
                            # Condition: "Next one after has increased"
                            # If this is the last point, it cannot "recover", so fail.
                            if j == len(prices) - 1:
                                is_linear = False; break
                            
                            next_p = prices[j+1]
                            if next_p <= curr_p:
                                is_linear = False; break # Next point failed to increase
                        
                        drift = abs(curr_price - open_price) / open_price
                        
                        # Added Cap < 0.85
                        if is_linear and drift > DRIFT_THRESHOLD and leader_price < 0.85:
                            cost = min(50.0, self.balance * 0.20) 
                            shares = cost / leader_price
                            self.balance -= cost
                            
                            window_trade = {
                                "type": "LINEAR-T7",
                                "side": leader_side,
                                "entry": leader_price,
                                "shares": shares,
                                "cost": cost
                            }
                            print(f"  [T+7 LINEAR] Trend Confirmed! (Prices: {[round(p,3) for p in prices]})")
                            print(f"    -> BUY {leader_side} @ {leader_price:.3f} (Cost: ${cost:.2f})")
                
                # --- FALLBACK LOGIC AT T+9m (540s) ---
                if elapsed_sec == 540 and not window_trade:
                    drift = abs(curr_price - open_price) / open_price
                    # Added Cap < 0.85
                    if drift > DRIFT_THRESHOLD and leader_price < 0.85:
                         cost = min(50.0, self.balance * 0.10) 
                         shares = cost / leader_price
                         self.balance -= cost
                         
                         window_trade = {
                             "type": "STD-T9",
                             "side": leader_side,
                             "entry": leader_price,
                             "shares": shares,
                             "cost": cost
                         }
                         print(f"  [T+9 STANDARD] Fallback Entry.")
                         print(f"    -> BUY {leader_side} @ {leader_price:.3f} (Cost: ${cost:.2f})")

            # --- SETTLEMENT ---
            winner = "UP" if final_price > open_price else "DOWN"
            if window_trade:
                if window_trade["side"] == winner:
                    payout = window_trade["shares"]
                    profit = payout - window_trade["cost"]
                    self.balance += payout
                    self.wins += 1
                    print(f"  [WIN] Payout ${payout:.2f} (+${profit:.2f})")
                else:
                    self.losses += 1
                    print(f"  [LOSS] -${window_trade['cost']:.2f}")
            else:
                print(f"  [NO TRADE]")
                
            print(f"  Bal: ${self.balance:.2f}\n")

        self.print_report()

    def print_report(self):
        total = self.wins + self.losses
        print("==============================")
        print(f"Final Balance: ${self.balance:.2f}")
        print(f"Trades: {total} (W: {self.wins} L: {self.losses})")
        print("==============================")

def main():
    # 1. Scan for CSVs in data/
    files = sorted(glob.glob("data/*.csv") + glob.glob("poly_sim_shell/data/*.csv"))
    if not files:
        print("No CSV files found in data/.")
        return

    print("\nSelect Data File:")
    for idx, f in enumerate(files):
        print(f"{idx+1}. {f}")
    
    choice = input("Select [1]: ").strip()
    idx = int(choice) - 1 if choice else 0
    selected_file = files[idx]
    

    
    bal = input(f"Starting Balance [{DEFAULT_BUDGET}]: ").strip()
    balance = float(bal) if bal else DEFAULT_BUDGET
    
    sim = LinearTrendSimulation(selected_file, balance)
    sim.run()

if __name__ == "__main__":
    main()
