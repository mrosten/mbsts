"""
Simulator: LIVE Linear Trend Strategy (Paper Trader)

This script simulates the "Linear Trend" strategy in REAL-TIME using live Polymarket/Binance data.
It mimics `sim_trend_linear_1sec.py` but operates on live markets instead of historical CSVs.

Features:
- Real-Time Data Fetching (Polymarket + Binance)
- Robust Opening Price Logic (from bot_trend_t9_LIVE.py)
- 30-Second Sampling Intervals (T+5 to T+7)
- Relaxed Linear Trend Logic (5c leeway)
- Global Price Cap (< 0.85)
"""
import requests
import time
import json
import asyncio
import sys
from datetime import datetime, timezone, timedelta
import os

# --- Configuration ---
DRIFT_THRESHOLD = 0.0004
STATE_FILE = "sim_live_linear_state.json"
LOG_FILE = "sim_live_linear_log.txt"

def print_status(msg, log_to_file=False):
    timestamp = datetime.now().strftime("%H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    if log_to_file:
        with open(LOG_FILE, "a") as f:
            f.write(line + "\n")

class LiveLinearSimulator:
    def __init__(self, balance):
        self.balance = float(balance)
        self.session = requests.Session()
        
        # State
        self.is_running = True
        self.market_url = ""
        self.active_trade = None
        self.strategy_triggered = False
        self.checkpoints = {} # {second: price}
        
        # Data
        self.btc_offset = -86.0
        self.auto_offset = True
        self.last_offset_update = 0
        self.market_data = {
            "up_id": None, "down_id": None, 
            "up_price": 0.0, "down_price": 0.0,
            "btc_price": 0.0, 
            "open_price": 0.0,
            "start_ts": 0, "end_ts": 0
        }

    # --- Data Fetching (Reusable) ---
    def safe_load(self, val, default):
        if isinstance(val, (list, dict)): return val
        try: return json.loads(val)
        except: return default

    async def fetch_coingecko_price(self):
        try:
            url = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd"
            resp = await asyncio.to_thread(self.session.get, url, timeout=3.0)
            return float(resp.json()['bitcoin']['usd'])
        except: return 0.0

    async def get_historical_open(self, timestamp_ms):
        try:
            url = f"https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=1m&startTime={timestamp_ms}&limit=1"
            resp = await asyncio.to_thread(self.session.get, url, timeout=2)
            data = resp.json()
            if data and len(data) > 0:
                return float(data[0][1]) + self.btc_offset
        except: pass
        return 0.0

    async def fetch_spot_price(self):
        try:
            now = time.time()
            # Auto-Offset (Every 60s)
            if self.auto_offset and (now - self.last_offset_update > 60):
                cg = await self.fetch_coingecko_price()
                if cg > 0:
                    url = "https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT"
                    r = await asyncio.to_thread(self.session.get, url, timeout=1.5)
                    raw_b = float(r.json()["price"])
                    self.btc_offset = cg - raw_b
                    self.last_offset_update = now

            # Get Binance Price
            url = "https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT"
            resp = await asyncio.to_thread(self.session.get, url, timeout=1.5)
            data = resp.json()
            if "price" in data:
                price = float(data["price"]) + self.btc_offset
                self.market_data["btc_price"] = price
                
                # Logic: Fetch & Cache Open Price
                if self.market_data["open_price"] == 0 and self.market_data["start_ts"] > 0:
                     op = await self.get_historical_open(self.market_data["start_ts"] * 1000)
                     if op > 0: 
                         self.market_data["open_price"] = op
                         print_status(f"OPEN PRICE CACHED: {op:,.2f}")
                     elif (time.time() - self.market_data["start_ts"]) < 60:
                         self.market_data["open_price"] = price
                         print_status(f"OPEN PRICE SET (LIVE): {price:,.2f}")
        except: pass

    async def fetch_market_data(self):
        # 1. Get Token IDs
        if not self.market_data["up_id"] and self.market_url:
            try:
                slug = self.market_url.split("/")[-1].split("?")[0]
                url = f"https://gamma-api.polymarket.com/markets/slug/{slug}"
                resp = await asyncio.to_thread(self.session.get, url, timeout=2.0)
                if resp.status_code == 200:
                    data = resp.json()
                    if "clobTokenIds" in data:
                        ids = self.safe_load(data["clobTokenIds"], [])
                        # Robust mapping (Default or by Name)
                        up_id, down_id = None, None
                        if len(ids) >= 2:
                            up_id, down_id = ids[0], ids[1] # Default
                            
                        # Try name mapping
                        outcomes = self.safe_load(data.get("outcomes", "[]"), [])
                        if len(outcomes) >= 2:
                            for i, name in enumerate(outcomes):
                                if "Up" in name or "Yes" in name: up_id = ids[i]
                                elif "Down" in name or "No" in name: down_id = ids[i]
                        
                        self.market_data["up_id"] = up_id
                        self.market_data["down_id"] = down_id
            except: pass

        # 2. Get Prices
        if self.market_data["up_id"]:
            try:
                clob_url = "https://clob.polymarket.com/price"
                p1 = await asyncio.to_thread(self.session.get, clob_url, params={"token_id": self.market_data["up_id"], "side": "buy"})
                p2 = await asyncio.to_thread(self.session.get, clob_url, params={"token_id": self.market_data["down_id"], "side": "buy"})
                
                r1, r2 = p1.json(), p2.json()
                if "price" in r1: self.market_data["up_price"] = float(r1["price"])
                if "price" in r2: self.market_data["down_price"] = float(r2["price"])
            except: pass

    # --- Core Loop ---
    async def run(self):
        print(f"--- LIVE SIMULATOR: LINEAR TREND ---")
        print(f"Starting Balance: ${self.balance:.2f}")
        print("Calibrating Offset...")
        await self.fetch_spot_price()
        print(f"Offset: {self.btc_offset:.2f}")

        while self.is_running:
            try:
                # 1. Window Calculation
                now = datetime.now(timezone.utc)
                min15 = (now.minute // 15) * 15
                start_dt = now.replace(minute=min15, second=0, microsecond=0)
                ts_start = int(start_dt.timestamp())
                url = f"https://polymarket.com/event/btc-updown-15m-{ts_start}"

                # 2. Reset on New Window
                if url != self.market_url:
                    if self.market_url != "":
                        # Settle Previous
                        await self.settle_window()
                        
                    self.market_url = url
                    print(f"\n>> NEW WINDOW: {start_dt.strftime('%H:%M')} <<")
                    print(f"Monitoring: {self.market_url}")
                    
                    # Reset Data
                    btc_p = self.market_data["btc_price"]
                    self.market_data = {
                        "up_id": None, "down_id": None, 
                        "up_price": 0.0, "down_price": 0.0,
                        "btc_price": btc_p, 
                        "open_price": 0.0,
                        "start_ts": ts_start, "end_ts": ts_start + 900
                    }
                    self.checkpoints = {}
                    self.active_trade = None
                    self.strategy_triggered = False

                # 3. Fetch Data
                await self.fetch_spot_price()
                await self.fetch_market_data()

                # 4. Sampling & Strategy
                elapsed = int(time.time() - ts_start)
                
                # Update Status Line
                self.print_status_line(elapsed)

                if self.market_data["open_price"] > 0:
                     await self.process_strategy(elapsed)

                # 5. Smart Sleep (Aim for 5s intervals)
                await asyncio.sleep(5)

            except KeyboardInterrupt: break
            except Exception as e:
                print(f"Error: {e}")
                await asyncio.sleep(5)

    def print_status_line(self, elapsed):
        btc = self.market_data["btc_price"]
        op = self.market_data["open_price"]
        up = self.market_data["up_price"]
        dn = self.market_data["down_price"]
        
        drift = 0.0
        if op > 0: drift = abs(btc - op) / op
        
        trade_str = f"ACTIVE ({self.active_trade['type']})" if self.active_trade else "WAITING"
        t_str = f"T+{elapsed // 60}:{elapsed % 60:02d}"
        
        print(f"\r[{t_str}] BTC: {btc:,.1f} | OPEN: {op:,.1f} | UP: {up:.2f} DN: {dn:.2f} | Drift: {drift:.4%} | {trade_str}   ", end="", flush=True)

    async def process_strategy(self, elapsed):
        if self.strategy_triggered: return
        
        btc = self.market_data["btc_price"]
        op = self.market_data["open_price"]
        
        # Determine Leader
        leader_side = "UP" if btc > op else "DOWN"
        leader_price = self.market_data["up_price"] if leader_side == "UP" else self.market_data["down_price"]
        
        # --- SAMPLING (Every 30s: 300, 330, ..., 420) ---
        # Allow +/- 5s slack
        targets = [300, 330, 360, 390, 420]
        for t in targets:
            if abs(elapsed - t) <= 5:
                if t not in self.checkpoints:
                    self.checkpoints[t] = leader_price
                    # print_status(f"  [Checkpoint T+{t}s] {leader_side} @ {leader_price:.2f}")

        # --- LOGIC GATES ---
        drift = abs(btc - op) / op
        
        # 1. T+6 (360s) Early Entry
        if 360 <= elapsed <= 370 and not self.active_trade:
            if drift > DRIFT_THRESHOLD and leader_price < 0.85 and leader_price > 0.10:
                self.execute_trade("STD-T6", leader_side, leader_price, 0.15)

        # 2. T+7 (420s) Linear Trend
        if 420 <= elapsed <= 430 and not self.active_trade:
            required = [300, 330, 360, 390, 420]
            if all(t in self.checkpoints for t in required):
                # Verify Linearity (Relaxed)
                prices = [self.checkpoints[t] for t in required]
                is_linear = True
                
                for j in range(1, len(prices)):
                    curr_p = prices[j]
                    prev_p = prices[j-1]
                    if curr_p > prev_p: continue
                    
                    # Dip Check
                    dip = prev_p - curr_p
                    is_last = (j == len(prices) - 1)
                    
                    if dip > 0.05: is_linear = False; break
                    if is_last: is_linear = False; break # No recovery possible
                    
                    # Next must recover
                    # Note: We don't have j+1 in this loop (we need future knowledge?)
                    # Wait, 'prices' is fully populated if we are at T+7.
                    # Yes, we have the list.
                    next_p = prices[j+1]
                    if next_p <= curr_p: is_linear = False; break

                if is_linear and drift > DRIFT_THRESHOLD and leader_price < 0.85 and leader_price > 0.10:
                    self.execute_trade("LINEAR-T7", leader_side, leader_price, 0.20)
                    print_status(f"  [LINEAR TREND CONFIRMED] History: {prices}")

        # 3. T+9 (540s) Fallback
        if 540 <= elapsed <= 550 and not self.active_trade:
             if drift > DRIFT_THRESHOLD and leader_price < 0.85 and leader_price > 0.10:
                self.execute_trade("STD-T9", leader_side, leader_price, 0.10)

    def execute_trade(self, type_name, side, price, budget_pct):
        cost = min(50.0, self.balance * budget_pct)
        shares = cost / price
        self.balance -= cost
        
        self.active_trade = {
            "type": type_name,
            "side": side,
            "entry": price,
            "shares": shares,
            "cost": cost
        }
        self.strategy_triggered = True 
        print(f"\n\n>>> TRADE EXECUTED: {type_name} <<<")
        print(f"Side: {side} | Price: {price:.3f} | Cost: ${cost:.2f}")
        print_status(f"Entered {type_name} ({side}) @ {price:.3f}", log_to_file=True)

    async def settle_window(self):
        if not self.active_trade: return
        
        # Determine Winner logic
        btc = self.market_data["btc_price"]
        op = self.market_data["open_price"]
        
        if op == 0:
            print("Warning: No Open Price. Assuming Refund/No Action.")
            return

        winner = "UP" if btc > op else "DOWN"
        side = self.active_trade["side"]
        
        print(f"\n--- SETTLEMENT ---")
        print(f"Final BTC: {btc:,.1f} | Open: {op:,.1f} -> Winner: {winner}")
        
        if side == winner:
            payout = self.active_trade["shares"]
            profit = payout - self.active_trade["cost"]
            self.balance += payout
            print(f"RESULT: WIN! Payout: ${payout:.2f} (Profit: ${profit:.2f})")
            print_status(f"WIN: +${profit:.2f}", log_to_file=True)
        else:
            print(f"RESULT: LOSS. -${self.active_trade['cost']:.2f}")
            print_status(f"LOSS: -${self.active_trade['cost']:.2f}", log_to_file=True)
            
        print(f"New Balance: ${self.balance:.2f}")
        print("------------------")


if __name__ == "__main__":
    try:
        val = input("Enter Starting Balance [50.0]: ").strip()
        bal = float(val) if val else 50.0
        
        sim = LiveLinearSimulator(bal)
        asyncio.run(sim.run())
    except KeyboardInterrupt:
        print("\nSimulator Stopped.")
